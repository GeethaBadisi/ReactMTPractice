import React from 'react'

function DeletedToDo() {
  return (
    <div>DeletedToDo</div>
  )
}

export default DeletedToDo