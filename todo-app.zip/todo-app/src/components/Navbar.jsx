import React from 'react'
import './Navbar.css'
function Navbar() {
  return (
    <div className='navbar'>
        <h1 className='navbar-heading'>What needs to be done...</h1>
    </div>
  )
}

export default Navbar